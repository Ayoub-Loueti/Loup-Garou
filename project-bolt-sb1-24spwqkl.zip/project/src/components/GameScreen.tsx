import { useState, useEffect } from 'react';
import { Game, Player } from '../types/game';
import { supabase } from '../lib/supabase';
import NightPhase from './NightPhase';
import DayPhase from './DayPhase';

interface GameScreenProps {
  gameId: string;
  playerId: string;
  game: Game;
  currentPlayer: Player;
}

export default function GameScreen({ gameId, playerId, game, currentPlayer }: GameScreenProps) {
  const [players, setPlayers] = useState<Player[]>([]);

  useEffect(() => {
    fetchPlayers();

    const channel = supabase
      .channel(`game:${gameId}:players`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'players',
          filter: `game_id=eq.${gameId}`,
        },
        () => {
          fetchPlayers();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [gameId]);

  const fetchPlayers = async () => {
    const { data } = await supabase
      .from('players')
      .select('*')
      .eq('game_id', gameId)
      .order('position');

    if (data) {
      setPlayers(data);
    }
  };

  if (game.status === 'night') {
    return (
      <NightPhase
        game={game}
        gameId={gameId}
        currentPlayer={currentPlayer}
        players={players}
      />
    );
  }

  if (game.status === 'day') {
    return (
      <DayPhase
        game={game}
        gameId={gameId}
        currentPlayer={currentPlayer}
        players={players}
      />
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-slate-400">Chargement...</div>
    </div>
  );
}
