class SimpleVillageois extends ICard {
  constructor() {
    super();
    this.name = "Simple Villageois";
  }

  performAction() {
    console.log(`${this.name} has no special action.`);
  }

  getAbility() {
    return "None";
  }

  getName() {
    return this.name;
  }
}