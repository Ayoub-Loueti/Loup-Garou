class Voyante extends CardDecorator {
  constructor(card) {
    super(card);
    this.name = "Voyante";
  }

  performAction() {
    const target = null; // Placeholder for target selection
    if (target) {
      console.log(`${this.name} checked ${target.getName()}: Role is ${target.getRole().getName()}`);
    } else {
      console.log(`${this.name} could not find a target to check.`);
    }
  }

  getAbility() {
    return "Check a player's role at night";
  }

  getName() {
    return this.name;
  }
}