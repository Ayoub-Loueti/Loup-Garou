class GameController {
  constructor() {
    this.commandHistory = []; // Stack to store executed commands
    this.game = new Game(); // Instance of the Game class
  }

  // Execute a command and add it to history
  executeCommand(command) {
    if (command instanceof ICommand) {
      command.execute();
      this.commandHistory.push(command);
      console.log(`Command executed and added to history.`);
    } else {
      console.log("Invalid command type.");
    }
  }

  // Undo the last command
  undoLastCommand() {
    if (this.commandHistory.length > 0) {
      const lastCommand = this.commandHistory.pop();
      lastCommand.undo();
      console.log(`Last command undone.`);
    } else {
      console.log("No commands to undo.");
    }
  }

  // Add a player to the game (delegates to Game)
  addPlayer(player, joinCode) {
    this.game.addPlayer(player, joinCode);
  }

  // Start night phase (delegates to Game)
  startNight() {
    this.game.startNight();
  }

  // Start day phase (delegates to Game)
  startDay() {
    this.game.startDay();
  }
}