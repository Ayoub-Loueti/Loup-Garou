class IPlayerState {
  canAct() {
  }

  handleAction(player) {
  }
}