class Graveyard extends ICard {
  constructor() {
    super();
    this.deadCards = []; // Array to hold DeadCard objects
  }

  performAction() {
    if (this.deadCards.length === 0) {
      console.log("Graveyard is empty, no actions to perform.");
    } else {
      console.log("Graveyard actions:");
      this.deadCards.forEach(deadCard => deadCard.performAction());
    }
  }

  getAbility() {
    return `Contains ${this.deadCards.length} eliminated players`;
  }

  getName() {
    return "Graveyard";
  }

  // Add a player to the graveyard as a DeadCard
  addPlayer(player) {
    if (player.getState().constructor.name === "DeadPhase" && !this.deadCards.some(card => card.getPlayerName() === player.getName())) {
      const deadCard = new DeadCard(player);
      this.deadCards.push(deadCard);
      console.log(`Added ${deadCard.getPlayerName()} (${deadCard.getRoleName()}) to the ${this.getName()}`);
    } else {
      console.log(`${player.getName()} is not dead or already in the ${this.getName()}.`);
    }
  }

  // Get the list of DeadCard objects
  getDeadCards() {
    return this.deadCards;
  }

  // Log the current state of the graveyard
  logGraveyard() {
    if (this.deadCards.length === 0) {
      console.log(`${this.getName()} is empty.`);
    } else {
      console.log(`${this.getName()} contains:`);
      this.deadCards.forEach(card => {
        console.log(`- ${card.getPlayerName()} (${card.getRoleName()})`);
      });
    }
  }
}