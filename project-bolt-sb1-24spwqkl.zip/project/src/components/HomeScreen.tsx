import { useState } from 'react';
import { Moon, Users } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { generateCode } from '../lib/gameLogic';

interface HomeScreenProps {
  onJoinGame: (gameId: string, playerId: string) => void;
}

export default function HomeScreen({ onJoinGame }: HomeScreenProps) {
  const [mode, setMode] = useState<'menu' | 'host' | 'join'>('menu');
  const [playerName, setPlayerName] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleHostGame = async () => {
    if (!playerName.trim()) {
      setError('Please enter your name');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const hostCode = generateCode();
      const joinCode = generateCode();

      const { data: game, error: gameError } = await supabase
        .from('games')
        .insert({
          host_code: hostCode,
          join_code: joinCode,
          status: 'waiting',
        })
        .select()
        .single();

      if (gameError) throw gameError;

      const { data: player, error: playerError } = await supabase
        .from('players')
        .insert({
          game_id: game.id,
          name: playerName.trim(),
          is_host: true,
          position: 0,
        })
        .select()
        .single();

      if (playerError) throw playerError;

      onJoinGame(game.id, player.id);
    } catch (err) {
      setError('Failed to create game. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinGame = async () => {
    if (!playerName.trim()) {
      setError('Please enter your name');
      return;
    }

    if (!joinCode.trim()) {
      setError('Please enter a game code');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const { data: game, error: gameError } = await supabase
        .from('games')
        .select('*')
        .eq('join_code', joinCode.toUpperCase())
        .maybeSingle();

      if (gameError) throw gameError;
      if (!game) {
        setError('Game not found. Please check the code.');
        setLoading(false);
        return;
      }

      if (game.status !== 'waiting') {
        setError('This game has already started.');
        setLoading(false);
        return;
      }

      const { data: existingPlayers } = await supabase
        .from('players')
        .select('*')
        .eq('game_id', game.id);

      if (existingPlayers && existingPlayers.length >= 8) {
        setError('This game is full.');
        setLoading(false);
        return;
      }

      const { data: player, error: playerError } = await supabase
        .from('players')
        .insert({
          game_id: game.id,
          name: playerName.trim(),
          is_host: false,
          position: existingPlayers?.length || 0,
        })
        .select()
        .single();

      if (playerError) throw playerError;

      onJoinGame(game.id, player.id);
    } catch (err) {
      setError('Failed to join game. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-amber-600/20 rounded-full mb-4">
            <Moon className="w-10 h-10 text-amber-400" />
          </div>
          <h1 className="text-5xl font-bold text-amber-100 mb-2 tracking-wide">
            Loup-Garou
          </h1>
          <p className="text-slate-400 text-sm">
            Un jeu de déduction sociale pour 6-8 joueurs
          </p>
        </div>

        {mode === 'menu' && (
          <div className="space-y-4 animate-fadeIn">
            <button
              onClick={() => setMode('host')}
              className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white py-4 rounded-lg font-semibold text-lg hover:from-amber-500 hover:to-orange-500 transition-all transform hover:scale-105 shadow-lg"
            >
              Héberger une partie
            </button>
            <button
              onClick={() => setMode('join')}
              className="w-full bg-slate-700 text-slate-100 py-4 rounded-lg font-semibold text-lg hover:bg-slate-600 transition-all transform hover:scale-105 shadow-lg"
            >
              Rejoindre une partie
            </button>
          </div>
        )}

        {mode === 'host' && (
          <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl shadow-2xl border border-slate-700 animate-fadeIn">
            <h2 className="text-2xl font-bold text-amber-100 mb-4 flex items-center gap-2">
              <Users className="w-6 h-6" />
              Héberger une partie
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Votre nom
                </label>
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="Entrez votre nom"
                  maxLength={20}
                />
              </div>
              {error && (
                <div className="bg-red-900/30 border border-red-500 text-red-200 px-4 py-2 rounded-lg text-sm">
                  {error}
                </div>
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setMode('menu');
                    setError('');
                  }}
                  className="flex-1 bg-slate-700 text-slate-100 py-3 rounded-lg font-medium hover:bg-slate-600 transition-colors"
                >
                  Retour
                </button>
                <button
                  onClick={handleHostGame}
                  disabled={loading}
                  className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white py-3 rounded-lg font-medium hover:from-amber-500 hover:to-orange-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Création...' : 'Créer'}
                </button>
              </div>
            </div>
          </div>
        )}

        {mode === 'join' && (
          <div className="bg-slate-800/50 backdrop-blur-sm p-6 rounded-xl shadow-2xl border border-slate-700 animate-fadeIn">
            <h2 className="text-2xl font-bold text-amber-100 mb-4 flex items-center gap-2">
              <Users className="w-6 h-6" />
              Rejoindre une partie
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Votre nom
                </label>
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500"
                  placeholder="Entrez votre nom"
                  maxLength={20}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Code de partie
                </label>
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  className="w-full px-4 py-3 bg-slate-900 border border-slate-600 rounded-lg text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-amber-500 uppercase tracking-wider font-mono"
                  placeholder="XXXXXX"
                  maxLength={6}
                />
              </div>
              {error && (
                <div className="bg-red-900/30 border border-red-500 text-red-200 px-4 py-2 rounded-lg text-sm">
                  {error}
                </div>
              )}
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setMode('menu');
                    setError('');
                  }}
                  className="flex-1 bg-slate-700 text-slate-100 py-3 rounded-lg font-medium hover:bg-slate-600 transition-colors"
                >
                  Retour
                </button>
                <button
                  onClick={handleJoinGame}
                  disabled={loading}
                  className="flex-1 bg-gradient-to-r from-amber-600 to-orange-600 text-white py-3 rounded-lg font-medium hover:from-amber-500 hover:to-orange-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Connexion...' : 'Rejoindre'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
