class LoupGarou extends CardDecorator {
  constructor(card) {
    super(card);
    this.name = "Loup-Garou";
  }

  performAction() {
    const target = null; // Placeholder for target selection (to be implemented with game logic)
    if (target && target.getState().constructor.name !== "DeadPhase") {
      console.log(`${this.name} attacked ${target.getName()}`);
      target.setState(new DeadPhase());
    } else {
      console.log(`${this.name} could not find a valid target to attack.`);
    }
  }

  getAbility() {
    return "Attack a player at night";
  }

  getName() {
    return this.name;
  }
}