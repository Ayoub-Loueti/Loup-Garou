import { useState, useEffect } from 'react';
import { Moon, Eye, Skull, Shield, Droplet } from 'lucide-react';
import { Game, Player, NightAction, ROLE_NAMES } from '../types/game';
import { supabase } from '../lib/supabase';
import { getNextNightTurn, checkWinCondition } from '../lib/gameLogic';

interface NightPhaseProps {
  game: Game;
  gameId: string;
  currentPlayer: Player;
  players: Player[];
}

export default function NightPhase({ game, gameId, currentPlayer, players }: NightPhaseProps) {
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [hasActed, setHasActed] = useState(false);
  const [nightActions, setNightActions] = useState<NightAction[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastProtectedId, setLastProtectedId] = useState<string | null>(null);

  useEffect(() => {
    fetchNightActions();
    fetchLastProtected();
  }, [game.day_number]);

  const fetchNightActions = async () => {
    const { data } = await supabase
      .from('night_actions')
      .select('*')
      .eq('game_id', gameId)
      .eq('day_number', game.day_number);

    if (data) {
      setNightActions(data);
      const acted = data.some(action => action.actor_id === currentPlayer.id);
      setHasActed(acted);
    }
  };

  const fetchLastProtected = async () => {
    if (game.day_number <= 1) return;

    const { data } = await supabase
      .from('night_actions')
      .select('target_id')
      .eq('game_id', gameId)
      .eq('day_number', game.day_number - 1)
      .eq('action_type', 'salvateur_protect')
      .maybeSingle();

    if (data) {
      setLastProtectedId(data.target_id);
    }
  };

  const isMyTurn = game.current_turn === currentPlayer.role;
  const canAct = currentPlayer.is_alive && isMyTurn && !hasActed;

  const availableTargets = players.filter(p => {
    if (!p.is_alive || p.id === currentPlayer.id) return false;

    if (currentPlayer.role === 'salvateur' && p.id === lastProtectedId) {
      return false;
    }

    return true;
  });

  const handleAction = async () => {
    if (!selectedTarget || !canAct || loading) return;

    setLoading(true);

    try {
      let actionType = '';

      if (currentPlayer.role === 'loup_garou') {
        actionType = 'werewolf_kill';
      } else if (currentPlayer.role === 'voyante') {
        actionType = 'seer_vision';
      } else if (currentPlayer.role === 'salvateur') {
        actionType = 'salvateur_protect';
      }

      const targetPlayer = players.find(p => p.id === selectedTarget);

      await supabase.from('night_actions').insert({
        game_id: gameId,
        day_number: game.day_number,
        actor_id: currentPlayer.id,
        target_id: selectedTarget,
        action_type: actionType,
        result: { role: targetPlayer?.role },
      });

      if (currentPlayer.role === 'salvateur') {
        await supabase
          .from('players')
          .update({ protected_tonight: true })
          .eq('id', selectedTarget);
      }

      setHasActed(true);
    } catch (err) {
      console.error('Failed to perform action:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleEndTurn = async () => {
    if (loading) return;

    setLoading(true);

    try {
      const nextTurn = getNextNightTurn(game.current_turn, players);

      if (nextTurn === 'done') {
        await processNightEnd();
      } else {
        await supabase
          .from('games')
          .update({ current_turn: nextTurn })
          .eq('id', gameId);
      }
    } catch (err) {
      console.error('Failed to end turn:', err);
    } finally {
      setLoading(false);
    }
  };

  const processNightEnd = async () => {
    const werewolfKills = nightActions.filter(a => a.action_type === 'werewolf_kill');

    if (werewolfKills.length > 0) {
      const targetCounts = werewolfKills.reduce((acc, action) => {
        acc[action.target_id] = (acc[action.target_id] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const victimId = Object.entries(targetCounts).sort((a, b) => b[1] - a[1])[0][0];
      const victim = players.find(p => p.id === victimId);

      if (victim && !victim.protected_tonight) {
        await supabase
          .from('players')
          .update({ is_alive: false })
          .eq('id', victimId);
      }
    }

    await supabase
      .from('players')
      .update({ protected_tonight: false })
      .eq('game_id', gameId);

    const { data: updatedPlayers } = await supabase
      .from('players')
      .select('*')
      .eq('game_id', gameId);

    if (updatedPlayers) {
      const winner = checkWinCondition(updatedPlayers);

      if (winner) {
        await supabase
          .from('games')
          .update({
            status: 'ended',
            winner: winner,
            ended_at: new Date().toISOString(),
          })
          .eq('id', gameId);
        return;
      }
    }

    const discussionEndTime = new Date(Date.now() + 30000).toISOString();

    await supabase
      .from('games')
      .update({
        status: 'day',
        phase: 'discussion',
        discussion_end_time: discussionEndTime,
      })
      .eq('id', gameId);
  };

  const getRoleIcon = () => {
    switch (currentPlayer.role) {
      case 'loup_garou':
        return <Skull className="w-8 h-8" />;
      case 'voyante':
        return <Eye className="w-8 h-8" />;
      case 'salvateur':
        return <Shield className="w-8 h-8" />;
      case 'sorciere':
        return <Droplet className="w-8 h-8" />;
      default:
        return <Moon className="w-8 h-8" />;
    }
  };

  const getRoleAction = () => {
    switch (currentPlayer.role) {
      case 'loup_garou':
        return 'Choisissez une victime';
      case 'voyante':
        return 'Choisissez un joueur à examiner';
      case 'salvateur':
        return 'Choisissez un joueur à protéger';
      default:
        return 'Attendez votre tour';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-blue-950 to-slate-950 p-4">
      <div className="max-w-4xl mx-auto py-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-900/30 rounded-full mb-4">
            <Moon className="w-8 h-8 text-blue-300" />
          </div>
          <h1 className="text-4xl font-bold text-blue-100 mb-2">
            Nuit {game.day_number}
          </h1>
          <p className="text-blue-300">
            Le village dort...
          </p>
        </div>

        <div className="bg-slate-900/50 backdrop-blur-sm rounded-xl border border-blue-800/50 p-6 mb-6">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-12 h-12 bg-blue-900/30 rounded-full flex items-center justify-center text-blue-300">
              {getRoleIcon()}
            </div>
            <div>
              <h2 className="text-xl font-bold text-blue-100">
                {ROLE_NAMES[currentPlayer.role]}
              </h2>
              <p className="text-blue-300 text-sm">
                {isMyTurn ? getRoleAction() : 'En attente...'}
              </p>
            </div>
          </div>

          {!currentPlayer.is_alive && (
            <div className="bg-red-900/30 border border-red-500/50 rounded-lg p-4">
              <p className="text-red-200 text-center">
                Vous êtes mort. Vous ne pouvez plus agir.
              </p>
            </div>
          )}

          {currentPlayer.is_alive && !isMyTurn && (
            <div className="bg-blue-900/30 border border-blue-500/50 rounded-lg p-4">
              <p className="text-blue-200 text-center">
                {game.current_turn ? `C'est le tour des ${ROLE_NAMES[game.current_turn]}` : 'En attente...'}
              </p>
            </div>
          )}

          {canAct && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {availableTargets.map(player => (
                  <button
                    key={player.id}
                    onClick={() => setSelectedTarget(player.id)}
                    className={`p-4 rounded-lg border-2 transition-all ${
                      selectedTarget === player.id
                        ? 'bg-blue-600 border-blue-400 text-white'
                        : 'bg-slate-800 border-slate-700 text-slate-300 hover:border-blue-500'
                    }`}
                  >
                    <div className="text-center">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold mx-auto mb-2">
                        {player.name.charAt(0).toUpperCase()}
                      </div>
                      <p className="font-medium">{player.name}</p>
                    </div>
                  </button>
                ))}
              </div>

              <button
                onClick={handleAction}
                disabled={!selectedTarget || loading}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg font-semibold hover:from-blue-500 hover:to-purple-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? 'Action en cours...' : 'Confirmer'}
              </button>
            </div>
          )}

          {hasActed && isMyTurn && (
            <div className="space-y-4">
              <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-4">
                <p className="text-green-200 text-center">
                  Votre action a été effectuée
                </p>
              </div>

              <button
                onClick={handleEndTurn}
                disabled={loading}
                className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-white py-3 rounded-lg font-semibold hover:from-amber-500 hover:to-orange-500 transition-all disabled:opacity-50"
              >
                {loading ? 'Passage...' : 'Passer au suivant'}
              </button>
            </div>
          )}
        </div>

        <div className="bg-slate-900/50 backdrop-blur-sm rounded-xl border border-blue-800/50 p-6">
          <h3 className="text-lg font-semibold text-blue-100 mb-4">
            Joueurs vivants
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {players.filter(p => p.is_alive).map(player => (
              <div
                key={player.id}
                className="bg-slate-800/50 rounded-lg p-3 text-center"
              >
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-semibold mx-auto mb-2">
                  {player.name.charAt(0).toUpperCase()}
                </div>
                <p className="text-slate-300 text-sm">{player.name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
