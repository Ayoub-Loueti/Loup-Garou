import { useState, useEffect } from 'react';
import HomeScreen from './components/HomeScreen';
import LobbyScreen from './components/LobbyScreen';
import RoleRevealScreen from './components/RoleRevealScreen';
import GameScreen from './components/GameScreen';
import GameEndScreen from './components/GameEndScreen';
import { supabase } from './lib/supabase';
import { Game, Player } from './types/game';

type Screen = 'home' | 'lobby' | 'role_reveal' | 'game' | 'game_end';

function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [gameId, setGameId] = useState<string | null>(null);
  const [playerId, setPlayerId] = useState<string | null>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<Player | null>(null);

  useEffect(() => {
    if (!gameId) return;

    const channel = supabase
      .channel(`game:${gameId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'games',
          filter: `id=eq.${gameId}`,
        },
        (payload) => {
          const updatedGame = payload.new as Game;
          setGame(updatedGame);

          if (updatedGame.status === 'distributing_roles' && screen === 'lobby') {
            setScreen('role_reveal');
          } else if (updatedGame.status === 'night' || updatedGame.status === 'day') {
            if (screen === 'role_reveal' || screen === 'lobby') {
              setScreen('game');
            }
          } else if (updatedGame.status === 'ended' && screen !== 'game_end') {
            setScreen('game_end');
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [gameId, screen]);

  useEffect(() => {
    if (!playerId) return;

    const fetchPlayer = async () => {
      const { data } = await supabase
        .from('players')
        .select('*')
        .eq('id', playerId)
        .maybeSingle();

      if (data) {
        setCurrentPlayer(data);
      }
    };

    fetchPlayer();

    const channel = supabase
      .channel(`player:${playerId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'players',
          filter: `id=eq.${playerId}`,
        },
        (payload) => {
          setCurrentPlayer(payload.new as Player);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [playerId]);

  const handleJoinGame = (gId: string, pId: string) => {
    setGameId(gId);
    setPlayerId(pId);
    setScreen('lobby');
  };

  const handleStartGame = () => {
    setScreen('role_reveal');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900">
      {screen === 'home' && <HomeScreen onJoinGame={handleJoinGame} />}
      {screen === 'lobby' && gameId && playerId && (
        <LobbyScreen
          gameId={gameId}
          playerId={playerId}
          onStartGame={handleStartGame}
        />
      )}
      {screen === 'role_reveal' && playerId && (
        <RoleRevealScreen
          playerId={playerId}
          currentPlayer={currentPlayer}
          onContinue={() => setScreen('game')}
        />
      )}
      {screen === 'game' && gameId && playerId && game && currentPlayer && (
        <GameScreen
          gameId={gameId}
          playerId={playerId}
          game={game}
          currentPlayer={currentPlayer}
        />
      )}
      {screen === 'game_end' && gameId && game && (
        <GameEndScreen game={game} gameId={gameId} />
      )}
    </div>
  );
}

export default App;
