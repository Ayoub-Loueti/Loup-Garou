// Game class
class Game {
  constructor() {
    this.players = []; // Array to hold all players
    this.currentPhase = "sleep"; // Initial phase: "sleep", "playRole", "discussion", "vote"
    this.graveyard = []; // Simple array to track eliminated players
    this.code = this.generateCode(); // Unique code for the game
  }

  // Generate a random 6-character alphanumeric code
  generateCode() {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  // Add a player to the game with code validation
  addPlayer(player, joinCode) {
    if (joinCode === this.code && player && !this.players.includes(player)) {
      this.players.push(player);
      console.log(`${player.getName()} joined the game with code ${this.code}`);
    } else if (joinCode !== this.code) {
      console.log(`Invalid code ${joinCode} for ${player.getName()}, join failed.`);
    }
  }

  // Get the game code
  getCode() {
    return this.code;
  }

  // Set the current phase for all players
  setPhase(phase) {
    this.currentPhase = phase;
    this.players.forEach(player => {
      switch (phase) {
        case "sleep":
          player.setState(new SleepPhase());
          break;
        case "playRole":
          player.setState(new PlayRolePhase());
          break;
        case "discussion":
          player.setState(new DiscussionPhase());
          break;
        case "vote":
          player.setState(new VotePhase());
          break;
      }
    });
    console.log(`Game phase changed to ${phase}`);
  }

  // Start the night phase, triggering role actions
  startNight() {
    this.setPhase("playRole");
    this.players.forEach(player => {
      if (player.getState().canAct()) {
        player.performAction();
      }
    });
  }

  // Start the day phase, including discussion and voting
  startDay() {
    this.setPhase("discussion");
    this.players.forEach(player => {
      if (player.getState().canAct()) {
        player.performAction();
      }
    });
    this.setPhase("vote");
    this.players.forEach(player => {
      if (player.getState().canAct()) {
        player.performAction();
      }
    });
  }

  // Move eliminated players to graveyard (basic implementation)
  moveToGraveyard(player) {
    if (player.getState().constructor.name === "DeadPhase" && !this.graveyard.includes(player)) {
      this.graveyard.push(player);
      console.log(`${player.getName()} moved to graveyard`);
    }
  }

  // Get the number of living players
  getLivingPlayers() {
    return this.players.filter(player => player.getState().constructor.name !== "DeadPhase");
  }
}
