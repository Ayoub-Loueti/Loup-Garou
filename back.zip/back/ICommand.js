class ICommand {
  execute() {
  }

  undo() {
  }
}