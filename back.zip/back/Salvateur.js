class Salvateur extends CardDecorator {
  constructor(card) {
    super(card);
    this.name = "Salvateur";
    this.protectedPlayer = null; // Tracks the player protected this night
    this.lastProtectedPlayer = null; // Tracks the last protected player to prevent consecutive protection
  }

  performAction() {
    const target = null; // Placeholder for target selection
    const playerName = this.getName(); // Get the Salvateur's player name (via Player class when integrated)
    if (target && !this.protectedPlayer && target !== this.lastProtectedPlayer) {
      this.protectedPlayer = target;
      this.lastProtectedPlayer = target; // Update last protected player
      console.log(`${playerName} (Salvateur) protected ${target.getName()} from attack this night`);
    } else if (target === this.lastProtectedPlayer) {
      console.log(`${playerName} (Salvateur) cannot protect ${target.getName()} two nights in a row.`);
    } else if (this.protectedPlayer) {
      console.log(`${playerName} (Salvateur) has already protected someone this night.`);
    } else {
      console.log(`${playerName} (Salvateur) could not find a target to protect.`);
    }
  }

  getAbility() {
    return "Protect a player from attack at night (cannot protect the same player consecutively)";
  }

  getName() {
    return this.name;
  }

  isProtected(target) {
    return this.protectedPlayer === target;
  }

  // Reset protected player at the end of the night (to be called by Game)
  resetProtection() {
    this.protectedPlayer = null; // Clear protection for the next night
  }
}