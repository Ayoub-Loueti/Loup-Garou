class ICard {
  performAction() {
  }

  getAbility() {
  }

  getName() {
  }
}