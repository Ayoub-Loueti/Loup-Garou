class Chasseur extends CardDecorator {
  constructor(card) {
    super(card);
    this.name = "Chasseur";
    this.isActive = true; // One-time use upon death
  }

  performAction() {
    if (!this.isActive) return; // Only triggers on death
    const target = null; // Placeholder for target selection on death
    if (target) {
      console.log(`${this.name} shot ${target.getName()} upon death`);
      target.setState(new DeadPhase());
      this.isActive = false;
    } else {
      console.log(`${this.name} could not find a target to shoot upon death.`);
    }
  }

  getAbility() {
    return "Shoot a player upon death";
  }

  getName() {
    return this.name;
  }

  triggerDeathAction() {
    if (this.isActive) {
      this.performAction();
    }
  }
}