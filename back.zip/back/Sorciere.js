class Sorciere extends CardDecorator {
  constructor(card) {
    super(card);
    this.name = "Sorcière";
    this.potion = 1; // One-time use for the whole game
    this.used = false; // Track if potion is used
  }

  performAction() {
    if (this.potion > 0 && !this.used) {
      const target = null; // Placeholder for target selection
      if (target) {
        if (target.getState().constructor.name === "DeadPhase") {
          target.setState(new PlayRolePhase()); // Revive (simplified)
          console.log(`${this.name} revived ${target.getName()} with potion`);
        } else {
          target.setState(new DeadPhase()); // Kill
          console.log(`${this.name} killed ${target.getName()} with potion`);
        }
        this.potion--;
        this.used = true;
      } else {
        console.log(`${this.name} could not find a target to use potion on.`);
      }
    } else {
      console.log(`${this.name} has no potions left or already used it.`);
    }
  }

  getAbility() {
    return "Revive or kill a player once per game";
  }

  getName() {
    return this.name;
  }
}