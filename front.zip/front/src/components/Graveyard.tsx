import { Skull } from 'lucide-react';
import { Player, ROLE_NAMES } from '../types/game';
import { ROLE_IMAGES } from '../lib/images';

interface GraveyardProps {
  deadPlayers: Player[];
  isNightPhase?: boolean;
}

export default function Graveyard({ deadPlayers, isNightPhase = false }: GraveyardProps) {
  if (deadPlayers.length === 0) return null;

  return (
    <div className={`rounded-xl p-6 shadow-lg border-2 ${
      isNightPhase
        ? 'bg-slate-900/50 backdrop-blur-sm border-blue-800/50'
        : 'bg-white/80 backdrop-blur-sm border-amber-300'
    }`}>
      <div className="flex items-center gap-3 mb-4">
        <Skull className={`w-6 h-6 ${isNightPhase ? 'text-blue-300' : 'text-amber-700'}`} />
        <h3 className={`text-lg font-semibold ${
          isNightPhase ? 'text-blue-100' : 'text-amber-900'
        }`}>
          Cimetière ({deadPlayers.length})
        </h3>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {deadPlayers.map((player) => (
          <div
            key={player.id}
            className={`rounded-lg overflow-hidden shadow-md border-2 ${
              isNightPhase
                ? 'bg-slate-800/50 border-slate-700'
                : 'bg-amber-50 border-amber-200'
            }`}
          >
            <div className="relative aspect-[2/3]">
              <img
                src={ROLE_IMAGES[player.role as keyof typeof ROLE_IMAGES]}
                alt={ROLE_NAMES[player.role as keyof typeof ROLE_NAMES]}
                className="w-full h-full object-cover opacity-60 grayscale"
              />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <Skull className="w-12 h-12 text-red-500" />
              </div>
            </div>
            <div className={`p-2 text-center ${
              isNightPhase ? 'bg-slate-900/50' : 'bg-amber-100'
            }`}>
              <p className={`font-medium text-sm truncate ${
                isNightPhase ? 'text-blue-200' : 'text-amber-900'
              }`}>
                {player.name}
              </p>
              <p className={`text-xs ${
                isNightPhase ? 'text-blue-400' : 'text-amber-700'
              }`}>
                {ROLE_NAMES[player.role as keyof typeof ROLE_NAMES]}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
