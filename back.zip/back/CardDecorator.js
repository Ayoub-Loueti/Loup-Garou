class CardDecorator extends ICard {
  constructor(card) {
    super();
    this.card = card; // The wrapped card (base role or another decorator)
  }

  performAction() {
    if (this.card) {
      this.card.performAction(); // Delegate to the wrapped card
    }
  }

  getAbility() {
    return this.card ? this.card.getAbility() : "No ability";
  }

  getName() {
    return this.card ? `${this.card.getName()} (Decorated)` : "Unknown Role";
  }
}
