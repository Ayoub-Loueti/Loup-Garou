class VoteCommand extends ICommand {
  constructor(voter, target) {
    super();
    this.voter = voter; // The player casting the vote
    this.target = target; // The player being voted against
    this.wasEliminated = false; // Track if the vote resulted in elimination
  }

  execute() {
    if (this.voter.getState().constructor.name === "VotePhase" && this.voter.getState().canAct()) {
      this.voter.getState().handleAction(this.voter); // Trigger the vote action
      if (this.target.getState().constructor.name === "DeadPhase") {
        this.wasEliminated = true;
      }
      console.log(`${this.voter.getName()} executed a vote command against ${this.target.getName()}`);
    } else {
      console.log(`${this.voter.getName()} cannot vote in the current state.`);
    }
  }

  undo() {
    if (this.wasEliminated) {
      this.target.setState(new VotePhase()); // Revert to alive state (simplified)
      this.wasEliminated = false;
      console.log(`${this.target.getName()} was revived by undoing the vote.`);
    } else {
      console.log(`No elimination to undo for ${this.voter.getName()}'s vote against ${this.target.getName()}.`);
    }
    // Reset vote count (simplified, assumes single vote per phase)
    if (this.voter.getState().constructor.name === "VotePhase") {
      this.voter.getState().voteCount = 0; // Reset for undo
    }
  }
}