class RoleActionCommand extends ICommand {
  constructor(player) {
    super();
    this.player = player; // The player performing the role action
    this.previousState = null; // To store state before action (for undo)
  }

  execute() {
    if (this.player.getState().constructor.name === "PlayRolePhase" && this.player.getState().canAct()) {
      this.previousState = this.player.getState(); // Store current state before action
      this.player.performAction(); // Trigger the role's action
      console.log(`${this.player.getName()} executed a role action command.`);
    } else {
      console.log(`${this.player.getName()} cannot perform a role action in the current state.`);
    }
  }

  undo() {
    if (this.previousState) {
      // Simplified undo: Revert to previous state (e.g., undo kill by reviving)
      if (this.player.getRole() instanceof LoupGarou && this.player.getState().constructor.name === "PlayRolePhase") {
        // Assume last action was an attack; revert the target (placeholder)
        const target = null; // Needs game logic to track the last target
        if (target && target.getState().constructor.name === "DeadPhase") {
          target.setState(new PlayRolePhase()); // Revert elimination
          console.log(`${this.player.getName()}'s role action undone, ${target.getName()} revived.`);
        }
      }
      console.log(`${this.player.getName()}'s role action undone.`);
    } else {
      console.log(`No previous state to undo for ${this.player.getName()}'s role action.`);
    }
  }
}